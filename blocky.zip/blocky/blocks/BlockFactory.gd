# File: res://sequencer/BlockFactory.gd
class_name BlockFactory
extends RefCounted

enum Shape { LINE_FULL, LINE_HALF, SQUARE, L_SHAPE, T_SHAPE, DOT, LONG_4, LONG_5, LONG_6, LONG_7, LONG_8 }

static func create_random_block(available_status_effects: Array) -> BlockData:
	var block = BlockData.new()
	block.remaining_integrity = 5.0 
	block.shot_type = BlockData.ShotType.SINGLE
	block.behavior = GlobalState.BASIC_SHOOT_BEHAVIOR
	
	# 1. Roll for the weighted shape
	var shape = _get_weighted_shape()
	
	match shape:
		# Small (40%)
		Shape.DOT: _apply_shape(block, 1, 1, [true])
		Shape.LINE_HALF: _apply_shape(block, 1, 2, [true, true])
		# Heavy (40%)
		Shape.LONG_4: _apply_shape(block, 1, 4, [true, true, true, true])
		Shape.LONG_5: _apply_shape(block, 1, 5, [true, true, true, true, true])
		Shape.LONG_6: _apply_shape(block, 1, 6, [true, true, true, true, true, true])
		Shape.LONG_7: _apply_shape(block, 1, 7, [true, true, true, true, true, true, true])
		Shape.LONG_8: _apply_shape(block, 1, 8, [true, true, true, true, true, true, true, true])
		# Standard (20%)
		Shape.LINE_FULL: _apply_shape(block, 1, 3, [true, true, true])
		Shape.SQUARE: _apply_shape(block, 2, 2, [true, true, true, true])
		Shape.L_SHAPE: _apply_shape(block, 2, 2, [true, false, true, true])
		Shape.T_SHAPE: _apply_shape(block, 3, 2, [true, true, true, false, true, false])

	# 2. Roll a 50/50 split between Plain Damage or Status Effect Payload
	var is_plain_damage = randf() <= 0.50
	
	if is_plain_damage or available_status_effects.is_empty():
		# Roll for the weighted flat base damage: 40% (0.25), 40% (0.5), 20% (1.0)
		var damage_roll = randf()
		
		if damage_roll <= 0.40:
			block.innate_damage = 0.25
			block.display_name = "Light Kinetic"
		elif damage_roll <= 0.80:
			block.innate_damage = 0.5
			block.display_name = "Medium Kinetic"
		else:
			block.innate_damage = 1.0
			block.display_name = "Heavy Kinetic"
			
		block.color = Color(0.6, 0.6, 0.6) # Sleek steel gray for physical kinetic blocks
	else:
		var chosen_effect = _get_weighted_effect(available_status_effects)
		
		if chosen_effect:
			var effect_wrapper = EffectData.new()
			effect_wrapper.status_effect = chosen_effect
			block.effects.append(effect_wrapper)
			
			block.display_name = effect_wrapper.get_display_name()
			block.color = _get_color_for_effect(chosen_effect.effect_id)
			block.innate_damage = 0.0

	return block

static func _get_weighted_shape() -> Shape:
	var roll = randf()
	if roll <= 0.40: # 40% Chance for Small/Utility[cite: 37]
		return [Shape.DOT, Shape.LINE_HALF].pick_random()
	elif roll <= 0.80: # 40% Chance for Heavy/Encumbrance[cite: 37]
		return [Shape.LONG_4, Shape.LONG_5, Shape.LONG_6, Shape.LONG_7, Shape.LONG_8].pick_random()
	else: # 20% Chance for Standard[cite: 37]
		return [Shape.SQUARE, Shape.L_SHAPE, Shape.T_SHAPE, Shape.LINE_FULL].pick_random()

static func _get_weighted_effect(available: Array) -> Resource:
	var common_pool = []
	var uncommon_pool = []
	var rare_pool = []
	
	# Sort available effects into their rarity tiers[cite: 37]
	for effect in available:
		match effect.effect_id:
			"fear", "confusion", "deflect": 
				common_pool.append(effect)
			"spikes", "contagious": 
				uncommon_pool.append(effect)
			"slimed", "frail", "shock": 
				rare_pool.append(effect)
			
	var roll = randf()
	var selected_pool = []
	
	# Probability split: 50% Common, 30% Uncommon, 20% Rare[cite: 37]
	if roll <= 0.50 and not common_pool.is_empty():
		selected_pool = common_pool
	elif roll <= 0.80 and not uncommon_pool.is_empty():
		selected_pool = uncommon_pool
	elif not rare_pool.is_empty():
		selected_pool = rare_pool
	else:
		return available.pick_random()
		
	return selected_pool.pick_random()

static func _get_color_for_effect(effect_id: String) -> Color:
	match effect_id:
		"fear": return Color(0.8, 0.2, 1.0)
		"confusion": return Color(1.0, 0.5, 0.0)
		"deflect": return Color(0.8, 0.8, 0.9)
		"spikes": return Color(0.4, 0.4, 0.4)
		"contagious": return Color(0.6, 0.8, 0.2)
		"slimed": return Color(0.2, 0.9, 0.4)
		"frail": return Color(0.9, 0.9, 0.4)
		"shock": return Color(1.0, 1.0, 0.0)
		_: return Color.WHITE

static func _apply_shape(block: BlockData, w: int, h: int, mask: Array):
	block.width = w
	block.height = h
	var typed_mask: Array[bool] = []
	typed_mask.assign(mask)
	block._shape_mask_data = typed_mask
