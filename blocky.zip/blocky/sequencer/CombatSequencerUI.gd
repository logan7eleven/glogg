# File: res://sequencer/CombatSequencerUI.gd
extends ColorRect

@export var sequencer_manager: Node

const GRID_COLS = 16
const GRID_ROWS = 3
const CELL_SIZE = Vector2(16, 16) # Smaller footprint for the combat HUD

@onready var playhead = ColorRect.new()

func _ready():
	# Configure the background
	custom_minimum_size = Vector2(GRID_COLS * CELL_SIZE.x, GRID_ROWS * CELL_SIZE.y)
	size = custom_minimum_size
	color = Color(0.1, 0.1, 0.1, 0.8) # Semi-transparent dark background
	
	_draw_blocks()
	
	# Configure the playhead
	playhead.color = Color(1, 1, 1, 0.5) # Semi-transparent white bar
	playhead.size = Vector2(CELL_SIZE.x, size.y)
	add_child(playhead)

func _draw_blocks():
	for entry in GlobalState.master_sequencer_blocks:
		var block: BlockData = entry["block"]
		var origin: Vector2i = entry["origin"]
		
		# Draw each active cell individually
		for y in range(block.height):
			for x in range(block.width):
				if block.is_cell_active(x, y):
					var cell_rect = ColorRect.new()
					cell_rect.color = block.color
					var cell_x = origin.x + x
					var cell_y = origin.y + y
					cell_rect.position = Vector2(cell_x, cell_y) * CELL_SIZE
					cell_rect.size = CELL_SIZE
					add_child(cell_rect)

	for origin in GlobalState.obstacle_origins:
		var cell_rect = ColorRect.new()
		cell_rect.color = Color(0.5, 0.0, 0.0, 0.8) # Dark Red
		cell_rect.position = Vector2(origin.x, 0) * CELL_SIZE
		cell_rect.size = Vector2(CELL_SIZE.x, CELL_SIZE.y * GRID_ROWS)
		
		add_child(cell_rect)

	for coord in GlobalState.grid_pollution.keys():
		var cell_rect = ColorRect.new()
		cell_rect.color = Color(0.2, 0.9, 0.2, 0.45) # Toxic Green
		cell_rect.position = Vector2(coord.x, coord.y) * CELL_SIZE
		cell_rect.size = CELL_SIZE
		add_child(cell_rect)

	# --- NEW: DRAW PERM & TEMP STORAGE ON COMBAT HUD ---
	# Start drawing storage items 15 pixels below the sequencer grid
	var current_y_offset = (GRID_ROWS * CELL_SIZE.y) + 15
	
	if GlobalState.master_perm_storage:
		_draw_storage_item(GlobalState.master_perm_storage, Vector2(0, current_y_offset), "Perm")
		current_y_offset += (GlobalState.master_perm_storage.height * CELL_SIZE.y) + 10
		
	for block in GlobalState.master_temp_storage:
		_draw_storage_item(block, Vector2(0, current_y_offset), "Temp")
		current_y_offset += (block.height * CELL_SIZE.y) + 10


# Helper function to draw the block shape and its descriptive text
func _draw_storage_item(block: BlockData, offset: Vector2, prefix: String):
	for y in range(block.height):
		for x in range(block.width):
			if block.is_cell_active(x, y):
				var cell_rect = ColorRect.new()
				cell_rect.color = block.color
				cell_rect.position = offset + (Vector2(x, y) * CELL_SIZE)
				cell_rect.size = CELL_SIZE
				add_child(cell_rect)
				
	var desc_label = Label.new()
	desc_label.text = prefix + ": " + block.display_name
	
	if block.get("innate_damage") != null and block.innate_damage > 0:
		desc_label.text += " | DMG: " + str(block.innate_damage)
	
	if not block.get("is_permanent"):
		desc_label.text += " | Life: " + str(snapped(block.remaining_integrity, 0.1)) + "s"
		
	# Position text nicely to the right of the block shape
	desc_label.position = offset + Vector2((block.width * CELL_SIZE.x) + 10, 0)
	desc_label.add_theme_font_size_override("font_size", 12)
	add_child(desc_label)

func _process(_delta):
	if not is_instance_valid(sequencer_manager): return
	
	# Smoothly interpolate the playhead across the grid columns
	var step = sequencer_manager.current_step
	var progress = sequencer_manager.step_timer / sequencer_manager.SECONDS_PER_STEP
	playhead.position.x = (step + progress) * CELL_SIZE.x
