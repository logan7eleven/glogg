# File: res://sequencer/SequencerManager.gd
extends Node

const GRID_COLS = 16
const GRID_ROWS = 3

# 112.5 BPM = 1.875 beats per second = 2.133 seconds per 16-step loop
# 2.133 / 16 = 0.1333 seconds per step
const SECONDS_PER_STEP: float = 0.133333 

var spatial_grid: Array = []
var current_step: int = 0
var step_timer: float = 0.0
var is_active: bool = false

@onready var player: Node2D

func _ready():
	_rebuild_grid()
	
	# Wait for player to spawn, then start sequencer
	player = get_tree().get_first_node_in_group("players")
	is_active = true

func _rebuild_grid():
	# 1. Fully clear the existing spatial grid
	spatial_grid.clear()

	# 2. Build fresh
	_build_lookup_grid()
		
func _build_lookup_grid():
	spatial_grid.resize(GRID_COLS)
	for i in range(GRID_COLS):
		spatial_grid[i] = []
		spatial_grid[i].resize(GRID_ROWS)
		spatial_grid[i].fill(null)
		
	# Populate local grid from GlobalState master list
	for entry in GlobalState.master_sequencer_blocks:
		var block: BlockData = entry["block"]
		var origin: Vector2i = entry["origin"]
		
		for y in range(block.height):
			for x in range(block.width):
				if block.is_cell_active(x, y):
					var target_x = origin.x + x
					var target_y = origin.y + y
					if target_x < GRID_COLS and target_y < GRID_ROWS:
						# Store dictionary with block reference AND its root origin
						spatial_grid[target_x][target_y] = {
							"block": block,
							"origin": origin
						}

func _process(delta):
	# DYNAMIC FETCH: Find the player if we don't have them yet
	if not is_instance_valid(player):
		player = get_tree().get_first_node_in_group("players")
		return # Wait until next frame
		
	if not is_active: return
	
	# The Aiming Gate: only progress if aiming or finishing a mid-column fraction
	var is_aiming = player.aim_direction != Vector2.ZERO
	
	if is_aiming or step_timer > 0.0:
		step_timer += delta
		
		if step_timer >= SECONDS_PER_STEP:
			_execute_current_step()
			current_step = (current_step + 1) % GRID_COLS
			
			if not is_aiming:
				step_timer = 0.0 
			else:
				step_timer -= SECONDS_PER_STEP

func _execute_current_step():
	var unique_blocks_this_step: Dictionary = {}
	var column_total_height: int = 0
	
	var primary_behavior: Resource = null 
	var primary_block: BlockData = null 
	var primary_origin: Vector2i = Vector2i.ZERO
	
	for y in range(GRID_ROWS):
		var cell_data = spatial_grid[current_step][y]
		if cell_data == null: 
			continue
		
		var block: BlockData = cell_data["block"]
		var origin: Vector2i = cell_data["origin"]
		
		if unique_blocks_this_step.has(block): 
			continue
			
		unique_blocks_this_step[block] = origin

	for block in unique_blocks_this_step.keys():
		var origin = unique_blocks_this_step[block]
		column_total_height += block.height
		
		if primary_behavior == null and block.behavior != null:
			primary_behavior = block.behavior
			primary_block = block
			primary_origin = origin

	if column_total_height > 0 and primary_block:
		# 1. CALCULATE POLLUTION MISFIRE CHANCE
		var polluted_cells_covered: int = 0
		for y in range(primary_block.height):
			for x in range(primary_block.width):
				if primary_block.is_cell_active(x, y):
					var check_coord = primary_origin + Vector2i(x, y)
					if GlobalState.grid_pollution.has(check_coord):
						polluted_cells_covered += 1
		
		# 10% misfire chance per polluted cell covered
		var misfire_chance = float(polluted_cells_covered) * 0.1 
		
		if randf() < misfire_chance:
			print("MISFIRE! Block jammed due to grid pollution.")
			return # Abort firing entirely this step!

		# 2. FIRE THE WEAPON (If no misfire)
		var cumulative_damage = primary_block.get("innate_damage") if primary_block.get("innate_damage") != null else 0.0
		
		if primary_behavior and primary_behavior.has_method("execute"):
			# Failsafes just in case the player hasn't fully loaded their specific functions yet
			var gun_pos = player.get_gun_position() if player.has_method("get_gun_position") else player.global_position
			var aim_angle = player.get_aim_angle() if player.has_method("get_aim_angle") else 0.0
			primary_behavior.execute(gun_pos, aim_angle, cumulative_damage, primary_block.effects, primary_block)

		# 3. APPLY SEQUENCER DECAY & BREAKAGE (1 Hit Per Loop)
		# By checking `current_step == primary_origin.x`, wide blocks only take 
		# corrosion damage on the exact frame the playhead hits their left edge.
		if not primary_block.is_permanent and current_step == primary_origin.x:
			primary_block.remaining_integrity -= 0.1
			if primary_block.remaining_integrity <= 0.0:
				_handle_broken_block(primary_block, primary_origin)


# --- NEW: BREAKAGE, POLLUTION, AND BOSS FEEDING ---
func _handle_broken_block(broken_block: BlockData, origin: Vector2i):
	print("CRITICAL: ", broken_block.display_name, " shattered on the sequencer!")
	
	# 1. Send the specifics directly to the Boss
	GlobalState.run_threat_pool.append(broken_block)
	
	# 2. Pollute the exact grid spaces it was touching
	for y in range(broken_block.height):
		for x in range(broken_block.width):
			if broken_block.is_cell_active(x, y):
				var cell_coord = origin + Vector2i(x, y)
				GlobalState.grid_pollution[cell_coord] = true
				
	# 3. Remove it from the active grid memory
	for i in range(GlobalState.master_sequencer_blocks.size()):
		if GlobalState.master_sequencer_blocks[i]["block"] == broken_block:
			GlobalState.master_sequencer_blocks.remove_at(i)
			break
			
	# 4. Rebuild the live array so the block visually disappears
	_build_lookup_grid()
