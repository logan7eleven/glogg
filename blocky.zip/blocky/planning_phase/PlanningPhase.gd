# File: res://planning_phase/PlanningPhase.gd
extends Control

# --- CONSTANTS ---
const GRID_COLS = 16
const GRID_ROWS = 3
const CELL_SIZE = Vector2(32, 32)

# --- UI REFERENCES ---
@onready var bar_container: ColorRect = %BarContainer
@onready var temp_container: ColorRect = %TempContainer
@onready var perm_container: ColorRect = %PermContainer
@onready var selector: Control = %Selector
@onready var effect_label: Label = %EffectLabel

# --- SCENE PRELOADS ---
const BLOCK_UI_SCENE = preload("res://blocks/BlockUI.tscn")

# --- V2 STATE MANAGEMENT (Hierarchical Navigation) ---
enum State { 
	CONTAINER_SELECTION,  # Moving between the big boxes
	INSIDE_CONTAINER      # Moving the cursor inside a specific box
}
enum ContainerZone { SEQUENCER, PERM_STORAGE, TEMP_STORAGE }

var current_state: State = State.CONTAINER_SELECTION
var active_zone: ContainerZone = ContainerZone.SEQUENCER

# --- DATA MODEL ---
var spatial_grid: Array = [] 
var sequencer_blocks: Array[BlockData] = []
var temp_storage: Array[BlockData] = []
var perm_storage: BlockData = null

# --- NAVIGATION & HOLDING STATE ---
var held_block: BlockData = null
var held_origin_zone: ContainerZone
var held_origin_coords: Vector2i 
var grid_cursor: Vector2i = Vector2i.ZERO 

# =============================================================================
# INITIALIZATION
# =============================================================================

func _ready():
	spatial_grid.resize(GRID_COLS)
	for i in range(GRID_COLS):
		spatial_grid[i] = []
		spatial_grid[i].resize(GRID_ROWS)
		spatial_grid[i].fill(null)
		
	_enforce_storage_orientations()
	_load_from_global_state()
	_redraw_all_ui()

func _load_from_global_state():
	for entry in GlobalState.master_sequencer_blocks:
		held_block = entry["block"]
		grid_cursor = entry["origin"]
		active_zone = ContainerZone.SEQUENCER
		_place_held_block()
		
	held_block = null
	grid_cursor = Vector2i.ZERO
	current_state = State.CONTAINER_SELECTION
	active_zone = ContainerZone.SEQUENCER
	
	perm_storage = GlobalState.master_perm_storage
	temp_storage = GlobalState.master_temp_storage.duplicate()

func _save_and_exit():
	var layout_to_save: Array[Dictionary] = []
	for block in sequencer_blocks:
		var origin = _get_block_origin(block)
		layout_to_save.append({
			"block": block,
			"origin": origin
		})
	
	temp_storage.clear()
	GlobalState.save_planning_phase_state(layout_to_save, perm_storage)
	get_tree().change_scene_to_file("res://level.tscn")
	
	

# =============================================================================
# INPUT ROUTING
# =============================================================================

func _unhandled_input(event: InputEvent):
	if not is_visible_in_tree(): return
	var handled = false
	
	if event.is_action_pressed("ui_ready"):
		get_viewport().set_input_as_handled()
		_save_and_exit()
		return
		
	# Global Catch: Clear button (Square)
	if event.is_action_pressed("ui_clear"): # Assuming Square is mapped to ui_clear
		_on_clear_button_pressed()
		return
		
	# Global Catch: Rotate block anywhere as long as you are holding it
	if held_block != null and event.is_action_pressed("ui_rotate"):
		held_block.rotate_clockwise()
		_clamp_cursor_to_zone()
		handled = true
	else:
		match current_state:
			State.CONTAINER_SELECTION: handled = _handle_container_selection(event)
			State.INSIDE_CONTAINER: handled = _handle_inside_container(event)
				
	if handled:
		get_viewport().set_input_as_handled()
		_redraw_all_ui()

# =============================================================================
# STATE HANDLERS
# =============================================================================

func _handle_container_selection(event: InputEvent) -> bool:
	var dpad = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down").round()
	if dpad != Vector2.ZERO and event.is_action_pressed(dpad_to_action(dpad)):
		active_zone = (active_zone + 1) % 3 as ContainerZone
		_clamp_cursor_to_zone() 
		return true
		
	if event.is_action_pressed("ui_accept"):
		# X Button: Dive into the selected container
		current_state = State.INSIDE_CONTAINER
		_clamp_cursor_to_zone()
		return true
		
	if event.is_action_pressed("ui_cancel") and held_block != null:
		# Circle Button: If you back out entirely, cancel your grab and return the block
		_return_held_to_origin()
		return true

	return false

func _handle_inside_container(event: InputEvent) -> bool:
	if event.is_action_pressed("ui_cancel"):
		# Circle Button: Jump back out to the between-container selection!
		current_state = State.CONTAINER_SELECTION
		return true

	var dpad = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down").round()
	if dpad != Vector2.ZERO and event.is_action_pressed(dpad_to_action(dpad)):
		_navigate_blocks_in_zone(dpad)
		return true

	if event.is_action_pressed("ui_accept"):
		# X Button: Either drop what you have, or pick up what you are looking at
		if held_block != null:
			_place_held_block()
		else:
			var hovered = _get_hovered_block()
			if hovered != null:
				_pick_up_block(hovered, active_zone, grid_cursor)
		return true

	return false

# =============================================================================
# PLACEMENT & INVENTORY LOGIC
# =============================================================================

func _enforce_storage_orientations():
	if perm_storage != null:
		while perm_storage.height > GRID_ROWS and perm_storage.width <= GRID_ROWS:
			_rotate_block_data(perm_storage)
			
	for block in temp_storage:
		while block.height > GRID_ROWS and block.width <= GRID_ROWS:
			_rotate_block_data(block)

func _pick_up_block(block: BlockData, origin_zone: ContainerZone, coords: Vector2i):
	held_block = block
	held_origin_zone = origin_zone
	held_origin_coords = coords
	_remove_block_from_zone(block, origin_zone)
	_clamp_cursor_to_zone()

func _place_held_block():
	if active_zone == ContainerZone.SEQUENCER:
		if not _is_placement_valid(held_block, grid_cursor):
			effect_label.text = "ERROR: Invalid placement!"
			return 
			
		var covered = _get_covered_blocks(held_block, grid_cursor)
		for block in covered: _scrap_block(block, ContainerZone.SEQUENCER)

		for y in range(held_block.height):
			for x in range(held_block.width):
				if held_block.is_cell_active(x, y):
					var target_x = grid_cursor.x + x
					var target_y = grid_cursor.y + y
					if target_x < GRID_COLS and target_y < GRID_ROWS:
						spatial_grid[target_x][target_y] = held_block
		sequencer_blocks.append(held_block)

	elif active_zone == ContainerZone.PERM_STORAGE:
		if perm_storage != null: _scrap_block(perm_storage, ContainerZone.PERM_STORAGE)
		
		# NEW: Auto-rotate if it exceeds container height bounds
		while held_block.height > GRID_ROWS and held_block.width <= GRID_ROWS:
			_rotate_block_data(held_block)
			
		perm_storage = held_block
		
	elif active_zone == ContainerZone.TEMP_STORAGE:
		# NEW: Auto-rotate if it exceeds container height bounds
		while held_block.height > GRID_ROWS and held_block.width <= GRID_ROWS:
			_rotate_block_data(held_block)
			
		temp_storage.append(held_block) 

	held_block = null

func _rotate_block_data(block: BlockData):
	var new_width = block.height
	var new_height = block.width
	
	# FIX: Explicitly type this as Array[bool] so Godot accepts it!
	var new_mask: Array[bool] = [] 
	new_mask.resize(new_width * new_height)
	
	for y in range(block.height):
		for x in range(block.width):
			# Rotate 90 degrees
			var new_x = block.height - 1 - y
			var new_y = x
			var old_index = y * block.width + x
			var new_index = new_y * new_width + new_x
			new_mask[new_index] = block._shape_mask_data[old_index]
			
	block.width = new_width
	block.height = new_height
	block._shape_mask_data = new_mask

func _is_placement_valid(block: BlockData, cursor: Vector2i) -> bool:
	if cursor.x + block.width > GRID_COLS or cursor.y + block.height > GRID_ROWS:
		return false # Out of bounds
	
	# NEW: Build an array of just the blocked X columns
	var blocked_cols = []
	for obs in GlobalState.obstacle_origins:
		blocked_cols.append(obs.x)
	
	for y in range(block.height):
		for x in range(block.width):
			if block.is_cell_active(x, y):
				var check_coord = cursor + Vector2i(x, y)
				
				# Check if this cell lands anywhere in a blocked column
				if blocked_cols.has(check_coord.x):
					return false # Overlapping a solid 'X' column
					
	return true

func _return_held_to_origin():
	active_zone = held_origin_zone
	grid_cursor = held_origin_coords
	_place_held_block()
	current_state = State.CONTAINER_SELECTION

func _remove_block_from_zone(block: BlockData, zone: ContainerZone):
	if zone == ContainerZone.SEQUENCER:
		sequencer_blocks.erase(block)
		for x in range(GRID_COLS):
			for y in range(GRID_ROWS):
				if spatial_grid[x][y] == block:
					spatial_grid[x][y] = null
	elif zone == ContainerZone.PERM_STORAGE: perm_storage = null
	elif zone == ContainerZone.TEMP_STORAGE: temp_storage.erase(block)

func _get_covered_blocks(block: BlockData, coords: Vector2i) -> Array[BlockData]:
	var covered: Array[BlockData] = []
	for y in range(block.height):
		for x in range(block.width):
			if block.is_cell_active(x, y):
				var target_x = coords.x + x
				var target_y = coords.y + y
				if target_x < GRID_COLS and target_y < GRID_ROWS:
					var existing = spatial_grid[target_x][target_y]
					if existing != null and not covered.has(existing):
						covered.append(existing)
	return covered

func _scrap_block(block: BlockData, origin_zone: ContainerZone):
	_remove_block_from_zone(block, origin_zone)
	temp_storage.append(block)

func _on_clear_button_pressed():
	# Use duplicate to safely empty the list without crashing the loop!
	for block in sequencer_blocks.duplicate():
		_scrap_block(block, ContainerZone.SEQUENCER)
	_redraw_all_ui()

# =============================================================================
# NAVIGATION MATH
# =============================================================================

func _navigate_blocks_in_zone(dir: Vector2):
	if active_zone == ContainerZone.SEQUENCER:
		grid_cursor.x += int(dir.x)
		grid_cursor.y += int(dir.y)
		_clamp_cursor_to_zone()

func _clamp_cursor_to_zone():
	if active_zone == ContainerZone.SEQUENCER:
		if held_block != null:
			grid_cursor.x = clamp(grid_cursor.x, 0, max(0, GRID_COLS - held_block.width))
			grid_cursor.y = clamp(grid_cursor.y, 0, max(0, GRID_ROWS - held_block.height))
		else:
			grid_cursor.x = clamp(grid_cursor.x, 0, GRID_COLS - 1)
			grid_cursor.y = clamp(grid_cursor.y, 0, GRID_ROWS - 1)
	else:
		grid_cursor = Vector2i.ZERO

func _get_hovered_block() -> BlockData:
	match active_zone:
		ContainerZone.SEQUENCER: return spatial_grid[grid_cursor.x][grid_cursor.y]
		ContainerZone.PERM_STORAGE: return perm_storage
		ContainerZone.TEMP_STORAGE: return temp_storage.back() if temp_storage.size() > 0 else null
	return null

func _get_block_origin(block: BlockData) -> Vector2i:
	var min_x = GRID_COLS
	var min_y = GRID_ROWS
	var found = false
	for x in range(GRID_COLS):
		for y in range(GRID_ROWS):
			if spatial_grid[x][y] == block:
				min_x = min(min_x, x)
				min_y = min(min_y, y)
				found = true
	if found: return Vector2i(min_x, min_y)
	return Vector2i.ZERO

func dpad_to_action(dpad: Vector2) -> String:
	if dpad.x > 0: return "ui_right"
	if dpad.x < 0: return "ui_left"
	if dpad.y > 0: return "ui_down"
	return "ui_up"

# =============================================================================
# UI VISUALS
# =============================================================================

func _redraw_all_ui():
	_enforce_storage_orientations()
	_clear_all_containers()
	
	for block in sequencer_blocks:
		var origin = _get_block_origin(block)
		var block_ui = _create_block_ui(block, bar_container)
		block_ui.position = Vector2(origin) * CELL_SIZE
	
	if perm_storage:
		var block_ui = _create_block_ui(perm_storage, perm_container)
		block_ui.position = Vector2.ZERO 
		
	var x_offset = 10.0
	for block in temp_storage:
		var block_ui = _create_block_ui(block, temp_container)
		block_ui.position = Vector2(x_offset, 10.0)
		x_offset += (block.width * CELL_SIZE.x) + 10.0

	if held_block:
		var block_ui = _create_block_ui(held_block, self)
		match active_zone:
			ContainerZone.SEQUENCER:
				block_ui.position = bar_container.position + (Vector2(grid_cursor) * CELL_SIZE)
				# Red Flash if hovering an invalid spot!
				if _is_placement_valid(held_block, grid_cursor):
					block_ui.modulate = Color(1.0, 1.0, 1.0, 0.6) # Standard ghost
				else:
					block_ui.modulate = Color(1.0, 0.2, 0.2, 0.8) # Solid red error tint
			ContainerZone.PERM_STORAGE:
				block_ui.position = perm_container.position
				block_ui.modulate = Color(1.0, 1.0, 1.0, 0.6)
			ContainerZone.TEMP_STORAGE:
				block_ui.position = temp_container.position
				block_ui.modulate = Color(1.0, 1.0, 1.0, 0.6)

	# --- DRAW OBSTACLES & POLLUTION ---
	for origin in GlobalState.obstacle_origins:
		var obs_ui = ColorRect.new()
		obs_ui.color = Color(0.5, 0.0, 0.0, 0.8)
		obs_ui.size = Vector2(CELL_SIZE.x, CELL_SIZE.y * GRID_ROWS)
		obs_ui.position = bar_container.position + (Vector2(origin.x, 0) * CELL_SIZE)
		
		var x_label = Label.new()
		x_label.text = "X"
		x_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		x_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		x_label.set_anchors_preset(Control.PRESET_FULL_RECT)
		obs_ui.add_child(x_label)
		add_child(obs_ui)
		
	for coord in GlobalState.grid_pollution.keys():
		var poll_ui = ColorRect.new()
		poll_ui.color = Color(0.2, 0.9, 0.2, 0.35) 
		poll_ui.size = CELL_SIZE
		poll_ui.position = bar_container.position + (Vector2(coord) * CELL_SIZE)
		add_child(poll_ui)

	_update_selector_position()
	_update_effect_label()

func _create_block_ui(data: BlockData, parent: Node) -> BlockUI:
	var ui = BLOCK_UI_SCENE.instantiate()
	parent.add_child(ui)
	ui.update_display(data, CELL_SIZE)
	return ui

func _clear_all_containers():
	for child in bar_container.get_children(): child.queue_free()
	for child in perm_container.get_children(): child.queue_free()
	for child in temp_container.get_children(): child.queue_free()
	for child in get_children():
		if child is BlockUI: child.queue_free()

func _update_selector_position():
	if current_state == State.CONTAINER_SELECTION:
		# Draw the big box around the active container
		match active_zone:
			ContainerZone.SEQUENCER:
				selector.position = bar_container.position
				selector.size = bar_container.size
			ContainerZone.PERM_STORAGE:
				selector.position = perm_container.position
				selector.size = perm_container.size
			ContainerZone.TEMP_STORAGE:
				selector.position = temp_container.position
				selector.size = temp_container.size
	else:
		# Draw the small box around the cursor/held block
		match active_zone:
			ContainerZone.SEQUENCER:
				selector.position = bar_container.position + (Vector2(grid_cursor) * CELL_SIZE)
				if held_block: selector.size = Vector2(held_block.width, held_block.height) * CELL_SIZE
				else: selector.size = CELL_SIZE
			ContainerZone.PERM_STORAGE:
				selector.position = perm_container.position
				selector.size = perm_container.size
			ContainerZone.TEMP_STORAGE:
				selector.position = temp_container.position
				selector.size = temp_container.size

func _update_effect_label():
	if effect_label == null: return

	if held_block != null:
		var text = "Holding: " + _get_block_effect_text(held_block)
		if active_zone == ContainerZone.SEQUENCER and current_state == State.INSIDE_CONTAINER:
			var covered = _get_covered_blocks(held_block, grid_cursor)
			if covered.size() > 0:
				text += " -> REPLACES: "
				for i in range(covered.size()):
					text += _get_block_effect_text(covered[i])
					if i < covered.size() - 1: text += ", "
		effect_label.text = text
	else:
		if current_state == State.INSIDE_CONTAINER:
			var hovered = _get_hovered_block()
			if hovered: effect_label.text = _get_block_effect_text(hovered)
			else: effect_label.text = "Empty Cell"
		else:
			match active_zone:
				ContainerZone.SEQUENCER: effect_label.text = "[Sequencer Zone]"
				ContainerZone.PERM_STORAGE: effect_label.text = "[Permanent Storage]"
				ContainerZone.TEMP_STORAGE: effect_label.text = "[Temporary Storage]"

func _get_block_effect_text(block: BlockData) -> String:
	if block == null: return "Empty Cell"
	
	var text = block.display_name
	
	# Display Damage
	if block.get("innate_damage") != null and block.innate_damage > 0:
		text += " | DMG: " + str(block.innate_damage)
		
	# Display Life/Battery
	if block.get("is_permanent") != null and block.is_permanent:
		text += " | [PERMANENT]"
	else:
		text += " | Life: " + str(snapped(block.remaining_integrity, 0.1)) + "s"
		
	# Display Status Effects
	var fx_names = []
	for fx_wrapper in block.effects:
		if fx_wrapper.status_effect:
			fx_names.append(fx_wrapper.status_effect.effect_id.capitalize())
	if fx_names.size() > 0:
		text += " | FX: " + ", ".join(fx_names)
		
	return text
