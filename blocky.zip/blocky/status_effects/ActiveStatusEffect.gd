extends Node
class_name ActiveStatusEffect 

var effect_data: StatusEffectData
var target_enemy: EnemyBase 
var level: int = 1
var source_slot_index: int = -1
var duration_timer: Timer

func _ready():
	# 1. Connect the built-in signal to your custom cleanup function
	tree_exiting.connect(_on_custom_cleanup)
	
	# 2. When the effect is applied, update the visual manager
	if is_instance_valid(target_enemy) and is_instance_valid(target_enemy.visual_manager):
		target_enemy.visual_manager.update_effect_visual(effect_data.effect_id, true)

func _on_custom_cleanup():
	# 3. This runs automatically right before the node is deleted
	if is_instance_valid(target_enemy) and is_instance_valid(target_enemy.visual_manager):
		target_enemy.visual_manager.update_effect_visual(effect_data.effect_id, false)

func initialize(data: StatusEffectData, target: EnemyBase, effect_level: int, slot_index: int):
	self.effect_data = data
	self.target_enemy = target
	self.level = effect_level
	self.source_slot_index = slot_index
	self.name = data.effect_id
	if not _on_apply():
		queue_free()

func increment_and_update_level(_triggering_slot_index: int, _source_description: String = ""):
	var new_level = level + 1
	var old_level = level
	level = new_level
	_on_level_change(old_level)

func _notification(what):
	if what == NOTIFICATION_PREDELETE: _on_remove()

# --- Virtual Methods ---
func _on_apply() -> bool:
	return true
func _on_level_change(_old_level: int): 
	pass

func _on_remove():
	if is_instance_valid(duration_timer):
		duration_timer.stop()

func _start_or_add_duration(add_duration: bool = false):
	var duration = effect_data.get_calculated_value(level, "base_duration", "level_bonus_duration", 0.0)
	if duration <= 0:
		if is_instance_valid(duration_timer):
			duration_timer.stop()
		return 
	if not duration_timer:
		duration_timer = Timer.new()
		duration_timer.one_shot = true
		add_child(duration_timer)
		duration_timer.timeout.connect(queue_free)
	var time_to_set = duration
	if add_duration and duration_timer.time_left > 0:
		time_to_set = duration_timer.time_left + duration
	duration_timer.wait_time = time_to_set
	duration_timer.start()
